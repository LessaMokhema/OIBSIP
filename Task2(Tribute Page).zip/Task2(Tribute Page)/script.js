document.addEventListener("DOMContentLoaded", function() {
    // Typing animation for the heading
    const typingHeading = document.getElementById("typing-heading");
    const text = typingHeading.innerText;
    typingHeading.innerText = "";
    let index = 0;

    function type() {
        if (index < text.length) {
            typingHeading.innerText += text.charAt(index);
            index++;
            setTimeout(type, 100);
        }
    }

    type();

    // Triggering other animations
    const sections = document.querySelectorAll("section");
    const windowHeight = window.innerHeight;

    function checkPosition() {
        for (const section of sections) {
            const positionFromTop = section.getBoundingClientRect().top;
            if (positionFromTop - windowHeight <= 0) {
                section.classList.add("visible");
            }
        }
    }

    function throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => (inThrottle = false), limit);
            }
        };
    }

    const throttleCheckPosition = throttle(checkPosition, 250);

    document.addEventListener("scroll", throttleCheckPosition);
    window.addEventListener("resize", throttleCheckPosition);

    checkPosition();
});
