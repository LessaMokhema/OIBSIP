document.addEventListener('DOMContentLoaded', function() {
    const display = document.querySelector('input[name="display"]');
    
    function clearDisplay() {
        display.value = '';
    }

    function deleteLastChar() {
        display.value = display.value.slice(0, -1);
    }

    function appendValue(value) {
        display.value += value;
    }

    function calculateResult() {
        try {
            display.value = eval(display.value);
        } catch (error) {
            display.value = 'Error';
        }
    }

    function calculateSquareRoot() {
        display.value = Math.sqrt(parseFloat(display.value));
    }

    function appendPercentage() {
        display.value = parseFloat(display.value) / 100;
    }

    function appendDecimal() {
        // Ensure there's no more than one decimal point
        if (display.value.indexOf('.') === -1) {
            display.value += '.';
        }
    }

    function calculateExponentiation() {
        display.value = eval(display.value.replace('^', '**'));
    }

    // Add event listeners to the buttons
    const buttons = document.querySelectorAll('.operator');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            const value = button.value;
            if (value === 'AC') {
                clearDisplay();
            } else if (value === 'DE') {
                deleteLastChar();
            } else if (value === '=') {
                if (display.value.includes('^')) {
                    calculateExponentiation();
                } else {
                    calculateResult();
                }
            } else if (value === '√') {
                calculateSquareRoot();
            } else if (value === '%') {
                appendPercentage();
            } else if (value === '.') {
                appendDecimal();
            } else {
                appendValue(value);
            }
        });
    });
});
