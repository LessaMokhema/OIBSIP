let signUpBtn = document.getElementById("signUpBtn");
let signInBtn = document.getElementById("signInBtn");
let nameField = document.getElementById("nameField");
let emailField = document.getElementById("emailField");
let passwordField = document.getElementById("passwordField");
let title = document.getElementById("title");

// Initially hide the nameField and emailField
nameField.style.display = "none";
emailField.style.display = "none";

signInBtn.onclick = function() {
    nameField.style.display = "none";
    emailField.style.display = "none";
    passwordField.style.display = "block";
    title.innerHTML = "Login";
    signUpBtn.classList.remove("disable");
    signInBtn.classList.add("disable");
};

signUpBtn.onclick = function() {
    nameField.style.display = "block";
    emailField.style.display = "block";
    passwordField.style.display = "block";
    title.innerHTML = "Sign Up";
    signUpBtn.classList.add("disable");
    signInBtn.classList.remove("disable");
};
